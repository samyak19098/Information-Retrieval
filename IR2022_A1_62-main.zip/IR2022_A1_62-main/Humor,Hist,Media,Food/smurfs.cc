
+------------------------------------+
! A Compilation of Anti-Smurf Poetry !
!                                    !
!+--------------------+ +-----------+!
!!By The Highwayman,  ! !  <haotic  !!
!!  and The $muggler  ! ! <omputing !!
!+--------------------+ +-----------+!
!With ideas from...                  !
!  Elric of Imrryr      +-----------+!
!  Demented Hacker      !  (C)1985  !!
!  Midnight Stalker     +-----------+!
!                                    !
!This File is Dedicated to Papa Smurf!
+------------------------------------+

+------------------------------------+
!      Call these cool BBS's         !
+------------------------------------+
! The Black Musket Inn (415)659-1967 !
! The Seadog BBSCC-Fur (415)657-9096 !
! The Haunted House    (415)941-7256 !
! The Shrine of Chaos  (415)659-1264 !
+------------------------------------+

Blue Smurf,
Red Smurf,
All we want is dead Smurf,
Kill Smurf,
Smash Smurf,
Break, Twist, and Maime Smurf.

Out comes a punk at dusk,
Killing Smurfs is a must,
Dead Smurfs feed his lust.

He hates Smurfs,
We hate Smurfs,
Kill Smurfs.

Take a Smurf,
Blow up it's head,
Smear around the blue stuff,
Cause its dead.
Point a gun,
Shoot its face,
Smurfs are a disgrace,
To thee human race.

Blue bodies,
Blue brains,
Smurfs drive me insane.
White pants,
Friends with ants,
Goody goody oh so lame,
Smurfs are gay all the same.

Papa Smurf,
Great Smurf War,
Slam a Smurf in your front door,
Live in the forrest,
Underneath a tree,
Kill a Smurf,
Then go free,
It isn't a crime,
To maime or blind,
Kut and Kill,
Little blue pill,
Kill, kill, kill.

Smurfs are blue,
Papa is red,
Who gives a shit,
Shoot them dead.

Smurfs are shit,
Shit is Smurf,
Smear there asses in the turf,
No Smurfs.

Anti Smurf,
Anti Blue,
Anti Papa,
Anti You,
Kill Smurfs,
Kill Papa,
Win the war,
No prisoners,
Kill Smurfs,
Everything that moves,
Shoot that which is blue.
Anti Smurf is good.

Oh no!
There back,
Prepare for a...
Neo Smurf attack!
Pro blue,
Little scum,
Squish one under your thumb.

Your all alone,
In your home,
You find a Smurf,
Break its bones.

Blender Time,
Blue Shake,
Kill it with a garden rake,
Anyway you can,
Rid this plane,
Little blue people drive you insane!

Global Domination,
Mass Frustration,
Nuclear bombs everywhere,
Little children without any hair.
Melting the hinges on your front door,
Aftershock of the Great Smurf War.

Take a Smurf,
Smash it's head,
Smash it,
Smash it,
Til it's dead.

Smurf Smurf,
Make me puke,
Smurf Smurf,
Use a nuke,
Smurf go away,
Smurfs are hella gay.

Splat a Smurf,
Melt and twist,
Smash it's tiny, mangled wrist.
Smurfs are dead,
Smurfs are insane,
Little blue bodies,
Little blue brains.

Smurf Smurf,
We want you dead,
Smurf dead Smurf chop off your head.

Bloody Smurf,
Cut Smurf,
All we want is dead smurf.

Take a Smurf,
Stab it with a knife,
Turn around kill Papa's wife,
Use a pipe,
Bludgean it to death,

[:=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=:]
[ (c)Copyright 1985-Chaotic Computing ]
[:=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=:]

                                           